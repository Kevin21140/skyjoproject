public class Splendor {

    private static GameFrame splendor;

    public static void main(String[] args) {
        splendor = new GameFrame("Splendor");
    }

    public static void startGame() {
        splendor.startGame();
    }
}
