public enum Type {
    WHITE,
    BLACK,
    RED,
    GREEN,
    BLUE,
    WILD
}
